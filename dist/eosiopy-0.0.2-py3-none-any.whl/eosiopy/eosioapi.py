eosio_api_dict = {
    "get_info": "/v1/chain/get_info",
    "get_block": "/v1/chain/get_block",
    "push_transaction": "/v1/chain/push_transaction",
    "abi_json_to_bin":"/v1/chain/abi_json_to_bin"
}
